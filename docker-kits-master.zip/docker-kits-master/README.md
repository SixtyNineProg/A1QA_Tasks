# **Environment for Test Developer task**

Для запуска приложения необходимо:

## Окружение:
  - Docker 
  - Docker Compose
  
## Доступ к проекту:
 - Проверить, есть ли доступ к [следующему проекту](https://github.com/a1qa-education-exam/task-sources). В случае отсутствия - запросить доступ у проверяющего.
 - В файле **docker-compose.yml** для переменных **GIT_USD**, **GIT_PWD** указать
 свой логин и пароль для доступа в GitHub.
 
## Предустановки

 - Необходимо установить **Docker** и **Docker Compose**.
 
 P.S. В случае проблем с **Docker For Windows** рекомендуется использовать 
 виртуальную машину с **Ubuntu Desktop**.
 - [Установка Docker на Linux](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
 - [Установка Docker на Windows](https://docs.docker.com/docker-for-windows/install/#install-docker-for-windows-desktop-app)
 - [Установка Docker Compose](https://docs.docker.com/compose/install/)
 
 
## Запуск
 Выполнить из корня проекта команду:
 - _docker-compose up -d_

## Запуск на Windows
 1. Удалить из docker-compose.yml строки:
 - _ volumes:
    - ./dump.sql:/docker-entrypoint-initdb.d/init.sql:ro
_
 2. Выполнить из корня проекта команду:
    - _docker-compose up -d_
 3. Выполнить команду docker ps, забрать id контейнера с базой данных
 4. Выполнить из корня проекта команду (подставить id, взятый на предыдущем шаге):
    - _docker cp dump.sql {id}:dump.sql_
 5. Выполнить команду
    - _docker exec -it {id} /bin/bash_
 6. Выполнить команду (пароль - password)
    - _mysql -p -u login union_reporting < dump.sql_
 7. Выйти из терминала
 8. Выполнить из корня проекта команду:
    - _docker-compose restart -d_

Приложение будет доступно по адресу:
- _localhost:8080/web_ - веб часть.
- _localhost:8080/api_ - API.

Где _localhost_ - адрес машины, на которой установлен Docker.
